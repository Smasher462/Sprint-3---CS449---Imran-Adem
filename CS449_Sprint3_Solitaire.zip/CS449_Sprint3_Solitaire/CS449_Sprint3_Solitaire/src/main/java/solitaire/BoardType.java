package solitaire;

/**
 * The board layouts required for Sprint 3.
 */
public enum BoardType {
    ENGLISH,
    HEXAGON,
    DIAMOND
}