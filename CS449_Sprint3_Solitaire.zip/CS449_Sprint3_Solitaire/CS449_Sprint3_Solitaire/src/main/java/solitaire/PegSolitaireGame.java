package solitaire;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

/**
 * We share board state and rules for both manual and automated Solitaire.
 */
public class PegSolitaireGame {

    /** Possible states for one location in the square backing grid. */
    public enum CellState {
        INVALID, // Location is outside the selected board shape.
        EMPTY,   // Valid board location with no peg.
        PEG      // Valid board location containing a peg.
    }

    /** A legal jump, described by its starting and destination coordinates. */
    public record Move(int fromRow, int fromCol, int toRow, int toCol) { }

    // Eight permitted jumps: horizontal, vertical and diagonal.
    private static final int[][] JUMPS = {
            {-2, -2}, {-2, 0}, {-2, 2},
            {0, -2},           {0, 2},
            {2, -2},  {2, 0},  {2, 2}
    };

    private int size;
    private BoardType boardType;
    private CellState[][] board;

    /** Creates a new game using the requested size and board type. */
    public PegSolitaireGame(int size, BoardType boardType) {
        startNewGame(size, boardType);
    }

    /**
     * Starts a fresh game using the chosen settings.
     * Every playable location starts with a peg except the center hole.
     */
    public final void startNewGame(int size, BoardType boardType) {
        validateSize(size);
        if (boardType == null) {
            throw new IllegalArgumentException("Board type cannot be null.");
        }

        this.size = size;
        this.boardType = boardType;
        this.board = new CellState[size][size];
        initializeBoard();
    }

    /** Initializes the selected board shape and leaves the center empty. */
    private void initializeBoard() {
        int center = size / 2;

        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                if (isPlayablePosition(row, col)) {
                    board[row][col] = CellState.PEG;
                } else {
                    board[row][col] = CellState.INVALID;
                }
            }
        }

        board[center][center] = CellState.EMPTY;
    }

    /**
     * Returns whether a grid location belongs to the selected board shape.
     */
    private boolean isPlayablePosition(int row, int col) {
        int center = size / 2;

        return switch (boardType) {
            case ENGLISH -> {
                // For size 7 this creates the familiar 33-hole cross board.
                int arm = Math.max(1, size / 3);
                int bandStart = arm;
                int bandEnd = size - arm - 1;
                boolean inCenterRows = row >= bandStart && row <= bandEnd;
                boolean inCenterColumns = col >= bandStart && col <= bandEnd;
                yield inCenterRows || inCenterColumns;
            }
            case DIAMOND ->
                    Math.abs(row - center) + Math.abs(col - center) <= center;
            case HEXAGON -> {
                // Axial-coordinate style hexagon represented in a square array.
                int q = col - center;
                int r = row - center;
                yield Math.max(Math.max(Math.abs(q), Math.abs(r)), Math.abs(q + r)) <= center;
            }
        };
    }

    /**
     * Checks whether a requested move follows the rules.
     * A peg jumps exactly two cells orthogonally or diagonally over a peg
     * and must land in an empty playable location.
     */
    public boolean isValidMove(int fromRow, int fromCol, int toRow, int toCol) {
        if (!isInBounds(fromRow, fromCol) || !isInBounds(toRow, toCol)) {
            return false;
        }
        if (board[fromRow][fromCol] != CellState.PEG || board[toRow][toCol] != CellState.EMPTY) {
            return false;
        }

        int rowDifference = toRow - fromRow;
        int colDifference = toCol - fromCol;

        boolean orthogonalJump =
                (Math.abs(rowDifference) == 2 && colDifference == 0)
                        || (rowDifference == 0 && Math.abs(colDifference) == 2);
        boolean diagonalJump =
                Math.abs(rowDifference) == 2 && Math.abs(colDifference) == 2;

        if (!orthogonalJump && !diagonalJump) {
            return false;
        }

        int jumpedRow = (fromRow + toRow) / 2;
        int jumpedCol = (fromCol + toCol) / 2;
        return board[jumpedRow][jumpedCol] == CellState.PEG;
    }

    /**
     * Performs a move if it is valid.
     * @return true when the move was completed, false if it was rejected.
     */
    public boolean makeMove(int fromRow, int fromCol, int toRow, int toCol) {
        if (!isValidMove(fromRow, fromCol, toRow, toCol)) {
            return false;
        }

        int jumpedRow = (fromRow + toRow) / 2;
        int jumpedCol = (fromCol + toCol) / 2;

        board[fromRow][fromCol] = CellState.EMPTY;
        board[jumpedRow][jumpedCol] = CellState.EMPTY;
        board[toRow][toCol] = CellState.PEG;
        return true;
    }

    /**
     * Returns every currently legal jump, this is used by the automated mode and tests.
     */
    public List<Move> getValidMoves() {
        List<Move> moves = new ArrayList<>();
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                if (board[row][col] != CellState.PEG) {
                    continue;
                }
                for (int[] jump : JUMPS) {
                    int toRow = row + jump[0];
                    int toCol = col + jump[1];
                    if (isValidMove(row, col, toRow, toCol)) {
                        moves.add(new Move(row, col, toRow, toCol));
                    }
                }
            }
        }
        return moves;
    }

    /** Returns true if the current board still has at least one legal jump. */
    public boolean hasValidMoves() {
        return !getValidMoves().isEmpty();
    }

    /**
     * Shared helper selects and executes one RANDOM legal move.
     * Manual randomization and autoplay use identical rules, not preset moves.
     */
    protected boolean playOneRandomMove(Random random) {
        Objects.requireNonNull(random, "Random generator cannot be null.");
        if (isGameOver()) {
            return false;
        }
        List<Move> moves = getValidMoves();
        if (moves.isEmpty()) {
            return false;
        }
        Move chosen = moves.get(random.nextInt(moves.size()));
        return makeMove(chosen.fromRow(), chosen.fromCol(), chosen.toRow(), chosen.toCol());
    }

    /** A manual game ends with one peg left or when no valid moves remain. */
    public boolean isGameOver() {
        return countPegs() == 1 || !hasValidMoves();
    }

    /** Counts the pegs currently remaining on the board. */
    public int countPegs() {
        int count = 0;
        for (CellState[] row : board) {
            for (CellState cell : row) {
                if (cell == CellState.PEG) {
                    count++;
                }
            }
        }
        return count;
    }

    /** Returns the rating specified by the project once a game has ended. */
    public String getRating() {
        if (!isGameOver()) {
            return "Game in progress";
        }
        return ratingForPegCount(countPegs());
    }

    /** Converts a final peg count to the rating stated in the project overview doc. */
    public static String ratingForPegCount(int pegCount) {
        if (pegCount <= 0) {
            throw new IllegalArgumentException("Peg count must be at least 1.");
        }
        if (pegCount == 1) {
            return "Outstanding";
        }
        if (pegCount == 2) {
            return "Very Good";
        }
        if (pegCount == 3) {
            return "Good";
        }
        return "Average";
    }

    /** Returns the state of one location so the GUI can draw the board. */
    public CellState getCell(int row, int col) {
        if (!isInBounds(row, col)) {
            throw new IndexOutOfBoundsException("Cell is outside the board.");
        }
        return board[row][col];
    }

    public int getSize() {
        return size;
    }

    public BoardType getBoardType() {
        return boardType;
    }

    private boolean isInBounds(int row, int col) {
        return row >= 0 && row < size && col >= 0 && col < size;
    }

    /**
     * Support manageable odd board sizes from 5 through 15.
     */
    private void validateSize(int size) {
        if (size < 5 || size > 15 || size % 2 == 0) {
            throw new IllegalArgumentException("Board size must be an odd number from 5 through 15.");
        }
    }
}