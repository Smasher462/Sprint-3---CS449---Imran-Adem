package solitaire;

import java.util.Random;

/**
 * Manual mode: a human chooses each jump. The Randomize button can also
 * advance this same board through a few randomly chosen legal jumps.
 */
public class ManualGame extends PegSolitaireGame {

    private final Random random;

    public ManualGame(int size, BoardType boardType) {
        this(size, boardType, new Random());
    }

    ManualGame(int size, BoardType boardType, Random random) {
        super(size, boardType);
        this.random = java.util.Objects.requireNonNull(random);
    }

    /** Performs a player selected jump, if the chosen move is legal. */
    public boolean playMove(int fromRow, int fromCol, int toRow, int toCol) {
        return makeMove(fromRow, fromCol, toRow, toCol);
    }

    /**
     * Randomizes the current manual board by playing up to maxMoves legal jumps.
     * Returns the actual number of jumps, possibly zero when already finished.
     */
    public int randomizeBoard(int maxMoves) {
        if (maxMoves < 1) {
            throw new IllegalArgumentException("Must request at least one move.");
        }
        int completed = 0;
        while (completed < maxMoves && playOneRandomMove(random)) {
            completed++;
        }
        return completed;
    }
}