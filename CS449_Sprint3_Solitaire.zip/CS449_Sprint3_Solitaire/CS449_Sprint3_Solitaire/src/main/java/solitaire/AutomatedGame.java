package solitaire;

import java.util.Random;

/**
 * Automated mode: the computer chooses one random legal move per turn.
 */
public class AutomatedGame extends PegSolitaireGame {

    private final Random random;

    public AutomatedGame(int size, BoardType boardType) {
        this(size, boardType, new Random());
    }

    AutomatedGame(int size, BoardType boardType, Random random) {
        super(size, boardType);
        this.random = java.util.Objects.requireNonNull(random);
    }

    /** Makes exactly one randomly selected valid jump if one exists. */
    public boolean playRandomMove() {
        return playOneRandomMove(random);
    }
}
