package solitaire;

import javax.swing.*;
import java.awt.*;

/**
 * Java Swing interface for Sprint 3. It handles buttons and drawing only,
 * all board rules are in PegSolitaireGame and its two subclasses.
 */
public class SolitaireGUI extends JFrame {

    private final JSpinner sizeSpinner = new JSpinner(new SpinnerNumberModel(7, 5, 15, 2));
    private final JRadioButton englishButton = new JRadioButton("English", true);
    private final JRadioButton hexagonButton = new JRadioButton("Hexagon");
    private final JRadioButton diamondButton = new JRadioButton("Diamond");
    private final JRadioButton manualButton = new JRadioButton("Manual", true);
    private final JRadioButton automatedButton = new JRadioButton("Automated");
    private final JButton newGameButton = new JButton("New Game");
    private final JButton autoplayButton = new JButton("Autoplay");
    private final JButton randomizeButton = new JButton("Randomize");
    private final JPanel boardPanel = new JPanel(new GridBagLayout());
    private final JLabel statusLabel = new JLabel("Choose settings and click New Game.", SwingConstants.CENTER);

    private int selectedSize = 7;
    private BoardType selectedType = BoardType.ENGLISH;
    private boolean automatedMode = false;
    private PegSolitaireGame game = new ManualGame(selectedSize, selectedType);

    // Two mouse clicks where first selects a peg, second selects its destination.
    private int selectedRow = -1;
    private int selectedCol = -1;

    // A Swing Timer makes the computer's turns visible without freezing the GUI.
    private final Timer autoplayTimer = new Timer(140, event -> advanceAutoplay());

    public SolitaireGUI() {
        super("Peg Solitaire - Sprint 3");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));
        setSize(900, 720);
        setMinimumSize(new Dimension(650, 550));
        createControls();
        refreshBoard();
        updateModeControls();
        setLocationRelativeTo(null);
    }

    /** Creates board selection, game-mode buttons, and gameplay controls. */
    private void createControls() {
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        topPanel.add(new JLabel("Board size:"));
        topPanel.add(sizeSpinner);
        ((JSpinner.DefaultEditor) sizeSpinner.getEditor()).getTextField().setEditable(false);

        ButtonGroup types = new ButtonGroup();
        types.add(englishButton);
        types.add(hexagonButton);
        types.add(diamondButton);
        topPanel.add(new JLabel("Board type:"));
        topPanel.add(englishButton);
        topPanel.add(hexagonButton);
        topPanel.add(diamondButton);

        ButtonGroup modes = new ButtonGroup();
        modes.add(manualButton);
        modes.add(automatedButton);
        topPanel.add(new JLabel("Mode:"));
        topPanel.add(manualButton);
        topPanel.add(automatedButton);
        topPanel.add(newGameButton);

        sizeSpinner.addChangeListener(event -> updateSelectedSize());
        englishButton.addActionListener(event -> updateSelectedType(BoardType.ENGLISH));
        hexagonButton.addActionListener(event -> updateSelectedType(BoardType.HEXAGON));
        diamondButton.addActionListener(event -> updateSelectedType(BoardType.DIAMOND));
        manualButton.addActionListener(event -> updateSelectedMode(false));
        automatedButton.addActionListener(event -> updateSelectedMode(true));
        newGameButton.addActionListener(event -> startNewGameFromControls());

        JPanel bottomPanel = new JPanel(new BorderLayout());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttons.add(autoplayButton);
        buttons.add(randomizeButton);
        autoplayButton.addActionListener(event -> startAutoplay());
        randomizeButton.addActionListener(event -> randomizeCurrentBoard());
        bottomPanel.add(statusLabel, BorderLayout.NORTH);
        bottomPanel.add(buttons, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);
        add(boardPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    /** The selected choices take effect when New Game is pressed. */
    private void updateSelectedSize() {
        selectedSize = (Integer) sizeSpinner.getValue();
    }

    private void updateSelectedType(BoardType type) {
        selectedType = type;
    }

    private void updateSelectedMode(boolean automatic) {
        automatedMode = automatic;
        statusLabel.setText("Mode selected: " + (automatic ? "Automated" : "Manual")
                + ". Press New Game to apply it.");
    }

    /** Creates the appropriate subclass for the selected mode and board. */
    private void startNewGameFromControls() {
        autoplayTimer.stop();
        game = automatedMode
                ? new AutomatedGame(selectedSize, selectedType)
                : new ManualGame(selectedSize, selectedType);
        clearSelection();
        refreshBoard();
        updateModeControls();
        statusLabel.setText("New " + (automatedMode ? "automated" : "manual") + " "
                + selectedType + " game. Pegs: " + game.countPegs());
    }

    /** Enable only the actions that make sense for the current game. */
    private void updateModeControls() {
        autoplayButton.setEnabled(game instanceof AutomatedGame && !autoplayTimer.isRunning()
                && !game.isGameOver());
        randomizeButton.setEnabled(game instanceof ManualGame && !game.isGameOver());
    }

    /**
     * Draws the English, Diamond, or hexagon rows.
     */
    private void refreshBoard() {
        int size = game.getSize();
        int cellPixels = Math.max(30, Math.min(48, 565 / size));
        boardPanel.removeAll();
        boardPanel.setLayout(new GridBagLayout());

        JPanel boardContents;
        if (game.getBoardType() == BoardType.HEXAGON) {
            boardContents = new JPanel(new GridLayout(size, 1));
            for (int row = 0; row < size; row++) {
                JPanel centeredRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
                for (int col = 0; col < size; col++) {
                    if (game.getCell(row, col) != PegSolitaireGame.CellState.INVALID) {
                        JButton button = createCellButton(row, col, cellPixels);
                        centeredRow.add(button);
                    }
                }
                boardContents.add(centeredRow);
            }
        } else {
            boardContents = new JPanel(new GridLayout(size, size, 2, 2));
            for (int row = 0; row < size; row++) {
                for (int col = 0; col < size; col++) {
                    if (game.getCell(row, col) == PegSolitaireGame.CellState.INVALID) {
                        JLabel blank = new JLabel();
                        blank.setPreferredSize(new Dimension(cellPixels, cellPixels));
                        boardContents.add(blank);
                    } else {
                        boardContents.add(createCellButton(row, col, cellPixels));
                    }
                }
            }
        }
        boardPanel.add(boardContents);
        boardPanel.revalidate();
        boardPanel.repaint();
    }

    private JButton createCellButton(int row, int col, int cellPixels) {
        boolean occupied = game.getCell(row, col) == PegSolitaireGame.CellState.PEG;
        JButton button = new JButton(occupied ? "●" : "");
        button.setPreferredSize(new Dimension(cellPixels, cellPixels));
        button.setMargin(new Insets(0, 0, 0, 0));
        button.setFocusPainted(false);
        button.setToolTipText("Row " + row + ", column " + col);
        button.setEnabled(game instanceof ManualGame && !game.isGameOver());
        if (row == selectedRow && col == selectedCol) {
            button.setBackground(new Color(255, 220, 110));
        }
        button.addActionListener(event -> handleCellClick(row, col));
        return button;
    }

    /** Do two click manual moves, invalid moves never change the underlying board. */
    private void handleCellClick(int row, int col) {
        if (!(game instanceof ManualGame manual) || game.isGameOver()) {
            return;
        }
        if (selectedRow == -1) {
            if (game.getCell(row, col) == PegSolitaireGame.CellState.PEG) {
                selectedRow = row;
                selectedCol = col;
                statusLabel.setText("Peg selected. Click an empty destination.");
                refreshBoard();
            } else {
                statusLabel.setText("Choose an occupied peg first.");
            }
            return;
        }
        if (selectedRow == row && selectedCol == col) {
            clearSelection();
            statusLabel.setText("Selection canceled.");
            refreshBoard();
            return;
        }
        boolean moved = manual.playMove(selectedRow, selectedCol, row, col);
        clearSelection();
        refreshBoard();
        showMoveResult(moved, "Manual move");
    }

    /** Randomize the current manual game by advancing 1-3 random legal jumps. */
    private void randomizeCurrentBoard() {
        if (!(game instanceof ManualGame manual)) {
            return;
        }
        int jumps = manual.randomizeBoard(3);
        clearSelection();
        refreshBoard();
        showMoveResult(jumps > 0, "Randomized " + jumps + " move(s)");
    }

    /** Start automated computer turns, the board remains and isn't hardcoded. */
    private void startAutoplay() {
        if (!(game instanceof AutomatedGame) || game.isGameOver()) {
            return;
        }
        clearSelection();
        autoplayTimer.start();
        updateModeControls();
        statusLabel.setText("Autoplay running. Pegs: " + game.countPegs());
    }

    /** One Timer tick equals to exactly one randomly selected valid computer move. */
    private void advanceAutoplay() {
        if (!(game instanceof AutomatedGame automated)) {
            autoplayTimer.stop();
            updateModeControls();
            return;
        }
        boolean moved = automated.playRandomMove();
        refreshBoard();
        if (!moved || game.isGameOver()) {
            autoplayTimer.stop();
            updateModeControls();
            statusLabel.setText("Automated game over. Rating: " + game.getRating()
                    + " (" + game.countPegs() + " peg(s) left)");
        } else {
            statusLabel.setText("Autoplay: " + game.countPegs() + " pegs remaining.");
        }
    }

    /** Show completion/rating only after the board reaches an end state. */
    private void showMoveResult(boolean moved, String action) {
        updateModeControls();
        if (game.isGameOver()) {
            statusLabel.setText("Game over. " + game.getRating()
                    + " (" + game.countPegs() + " peg(s) left)");
        } else if (!moved) {
            statusLabel.setText("Invalid move; board unchanged.");
        } else {
            statusLabel.setText(action + " completed. Pegs remaining: " + game.countPegs());
        }
    }

    private void clearSelection() {
        selectedRow = -1;
        selectedCol = -1;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SolitaireGUI().setVisible(true));
    }
}