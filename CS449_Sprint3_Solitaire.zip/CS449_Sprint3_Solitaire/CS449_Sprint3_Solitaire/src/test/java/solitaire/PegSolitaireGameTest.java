package solitaire;

import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Automated JUnit 5 tests for Sprint 3 manual and automated game logic.
 */
class PegSolitaireGameTest {

    @Test
    void englishBoardStartsWithEmptyCenter() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);

        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(3, 3));
        assertEquals(BoardType.ENGLISH, game.getBoardType());
    }

    @Test
    void hexagonBoardStartsWithEmptyCenter() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.HEXAGON);

        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(3, 3));
        assertEquals(BoardType.HEXAGON, game.getBoardType());
    }

    @Test
    void diamondBoardStartsWithEmptyCenter() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.DIAMOND);

        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(3, 3));
        assertEquals(BoardType.DIAMOND, game.getBoardType());
    }

    @Test
    void newGameUsesChosenSizeAndType() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);

        game.startNewGame(9, BoardType.DIAMOND);

        assertEquals(9, game.getSize());
        assertEquals(BoardType.DIAMOND, game.getBoardType());
        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(4, 4));
    }

    @Test
    void startingAnotherGameResetsTheBoard() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);
        assertTrue(game.makeMove(1, 3, 3, 3));
        assertEquals(PegSolitaireGame.CellState.PEG, game.getCell(3, 3));

        game.startNewGame(7, BoardType.ENGLISH);

        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(3, 3));
        assertEquals(PegSolitaireGame.CellState.PEG, game.getCell(1, 3));
        assertEquals(PegSolitaireGame.CellState.PEG, game.getCell(2, 3));
    }

    @Test
    void orthogonalJumpIsRecognizedAsValid() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);

        assertTrue(game.isValidMove(1, 3, 3, 3));
    }

    @Test
    void diagonalJumpIsRecognizedAsValid() {
        // Size 9 gives the Diamond board enough room for a diagonal jump into the center.
        PegSolitaireGame game = new PegSolitaireGame(9, BoardType.DIAMOND);

        assertTrue(game.isValidMove(2, 2, 4, 4));
    }

    @Test
    void validMoveMovesPegAndRemovesJumpedPeg() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);

        assertTrue(game.makeMove(1, 3, 3, 3));

        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(1, 3));
        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(2, 3));
        assertEquals(PegSolitaireGame.CellState.PEG, game.getCell(3, 3));
    }

    @Test
    void invalidMoveIsRejectedAndBoardDoesNotChange() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);
        int pegsBefore = game.countPegs();

        // Destination (2,3) already contains a peg, so this move is invalid.
        assertFalse(game.makeMove(0, 3, 2, 3));

        assertEquals(pegsBefore, game.countPegs());
        assertEquals(PegSolitaireGame.CellState.PEG, game.getCell(0, 3));
        assertEquals(PegSolitaireGame.CellState.PEG, game.getCell(2, 3));
    }

    @Test
    void newGameIsNotImmediatelyOver() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);

        assertFalse(game.isGameOver());
        assertTrue(game.hasValidMoves());
    }

    @Test
    void ratingsMatchTheProjectSpecification() {
        assertEquals("Outstanding", PegSolitaireGame.ratingForPegCount(1));
        assertEquals("Very Good", PegSolitaireGame.ratingForPegCount(2));
        assertEquals("Good", PegSolitaireGame.ratingForPegCount(3));
        assertEquals("Average", PegSolitaireGame.ratingForPegCount(4));
        assertEquals("Average", PegSolitaireGame.ratingForPegCount(10));
    }

    @Test
    void manualGameEndsWhenNoValidMovesRemain() {
        // Both English and Hexagon must be playable manually until game over.
        for (BoardType type : List.of(BoardType.ENGLISH, BoardType.HEXAGON)) {
            ManualGame game = new ManualGame(7, type);
            while (!game.isGameOver()) {
                PegSolitaireGame.Move move = game.getValidMoves().get(0);
                assertTrue(game.playMove(move.fromRow(), move.fromCol(),
                        move.toRow(), move.toCol()));
            }
            assertTrue(game.isGameOver());
            assertNotEquals("Game in progress", game.getRating());
        }
    }

    @Test
    void automatedTurnChoosesOneLegalMove() {
        AutomatedGame game = new AutomatedGame(7, BoardType.ENGLISH, new Random(12));
        List<PegSolitaireGame.Move> possibleMoves = game.getValidMoves();
        int before = game.countPegs();

        // The computer must choose among actual legal moves, not hardcoded ones.
        assertFalse(possibleMoves.isEmpty());
        assertTrue(game.playRandomMove());
        assertEquals(before - 1, game.countPegs());

        // Compare the board with each possible legitimate one-move result.
        boolean matchesLegalMove = false;
        for (PegSolitaireGame.Move move : possibleMoves) {
            ManualGame candidate = new ManualGame(7, BoardType.ENGLISH);
            candidate.playMove(move.fromRow(), move.fromCol(), move.toRow(), move.toCol());
            if (sameBoard(game, candidate)) {
                matchesLegalMove = true;
                break;
            }
        }
        assertTrue(matchesLegalMove);
    }

    @Test
    void automatedGameStopsWhenNoFurtherMoveIsPossible() {
        // Repeat for the two shapes required by the demo.
        for (BoardType type : List.of(BoardType.ENGLISH, BoardType.HEXAGON)) {
            AutomatedGame game = new AutomatedGame(7, type, new Random(42));
            int turns = 0;
            while (!game.isGameOver()) {
                assertTrue(game.playRandomMove());
                turns++;
                assertTrue(turns < 50, "Game should finish in fewer than 50 moves.");
            }
            assertTrue(turns > 0);
            assertTrue(game.isGameOver());
            assertNotEquals("Game in progress", game.getRating());
            assertFalse(game.playRandomMove());
        }
    }

    @Test
    void randomizeManualBoardMakesOnlyLegalMoves() {
        ManualGame game = new ManualGame(7, BoardType.ENGLISH, new Random(10));
        assertTrue(game.playMove(1, 3, 3, 3));
        int before = game.countPegs();

        // Randomize continues from the CURRENT manual board, not a new game.
        int randomMoves = game.randomizeBoard(3);
        assertTrue(randomMoves > 0);
        assertTrue(randomMoves <= 3);
        assertEquals(before - randomMoves, game.countPegs());
        assertEquals(BoardType.ENGLISH, game.getBoardType());
        assertEquals(7, game.getSize());

        // Once finished, Randomize must leave the board unchanged.
        while (!game.isGameOver()) {
            game.randomizeBoard(3);
        }
        int finishedCount = game.countPegs();
        assertEquals(0, game.randomizeBoard(3));
        assertEquals(finishedCount, game.countPegs());
    }

    // Compares two boards without any GUI interaction.
    private boolean sameBoard(PegSolitaireGame a, PegSolitaireGame b) {
        if (a.getSize() != b.getSize()) {
            return false;
        }
        for (int row = 0; row < a.getSize(); row++) {
            for (int col = 0; col < a.getSize(); col++) {
                if (a.getCell(row, col) != b.getCell(row, col)) {
                    return false;
                }
            }
        }
        return true;
    }
}